package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/*Crie um programa Java que permita ao usuário excluir um cliente da tabela "clientes" no banco de dados MariaDB. 
Solicite ao usuário que forneça o ID do cliente a ser excluído e remova-o da tabela.
 */

  /**
Garanta que, em todos os programas anteriores, você encerre a conexão com o banco de dados MariaDB adequadamente após a 
conclusão das operações. Use a estrutura try-with-resources ou um bloco finally para garantir o fechamento da conexão.
 */

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Digite o ID do cliente que quer excluir da tabela: ");
        int id = entrada.nextInt();

        String deleteSql = "DELETE from cliente WHERE id = ?";

        try (Connection conect = DriverManager.getConnection("jdbc:mariadb://localhost:3306/listachicoutbdb", "root", "root");
            //String deleteSql = "DELETE * from cliente WHERE id = " + id + "";

            PreparedStatement ps = conect.prepareStatement(deleteSql)) {
                ps.setInt(1, id);


            //Dar um feedback ao usuário informando se atualizou ou não a informação necessária
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuário Excluido com Sucesso.");
            } else {
                System.out.println("Nenhum usuário encontrado com o ID fornecido.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            entrada.close();
        }
    }
}