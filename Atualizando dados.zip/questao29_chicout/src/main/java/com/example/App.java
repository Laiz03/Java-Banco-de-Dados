package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 Modifique o programa da Questão 22 para permitir que o usuário atualize informações de um funcionario existente na tabela "funcionario".
 Peça ao usuário que insira o ID do funcionario a ser atualizado e, 
 em seguida, atualize os campos, como endereço ou número de telefone.
 */

 /**
Garanta que, em todos os programas anteriores, você encerre a conexão com o banco de dados MariaDB adequadamente após a 
conclusão das operações. Use a estrutura try-with-resources ou um bloco finally para garantir o fechamento da conexão.
 */

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        Scanner entrada = new Scanner(System.in);

        System.out.println("Qual ID do funcionario que deseja atualizar? ");
        int id = entrada.nextInt();
        entrada.nextLine();

        System.out.println("Qual é o novo endereço do funcionário? ");
        String novoEnd = entrada.nextLine();


        String updateSql = "UPDATE funcionario SET endereco = ? WHERE id = ?";

        try (Connection conect = DriverManager.getConnection("jdbc:mariadb://localhost:3306/listachicoutbdb", "root", "root");
             PreparedStatement ps = conect.prepareStatement(updateSql)) {
             
            ps.setString(1, novoEnd);
            ps.setInt(2, id);

            //Dar um feedback ao usuário informando se atualizou ou não a informação necessária
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Endereço atualizado com sucesso.");
            } else {
                System.out.println("Nenhum funcionário encontrado com o ID fornecido.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            entrada.close();
        }
    } 
}
