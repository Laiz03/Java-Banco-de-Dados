package com.example;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


/** Escreva um programa Java que utilize o JDBC para se conectar a um banco de dados MariaDB local. Certifique-se de configurar corretamente a URL de conexão, nome de usuário e senha. 
 * Após a conexão bem-sucedida, exiba uma mensagem de confirmação no console.
 */

 /**
Garanta que, em todos os programas anteriores, você encerre a conexão com o banco de dados MariaDB adequadamente após a 
conclusão das operações. Use a estrutura try-with-resources ou um bloco finally para garantir o fechamento da conexão.
 */

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        try (Connection conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/", "root", "root")) {
            try (Statement stmt = conn.createStatement()) {
                try (ResultSet rs = stmt.executeQuery("SELECT 'Hello World!'")) {
                    rs.first();
                    System.out.println(rs.getString(1));
                    System.out.println("Conexão com o banco de dados estabelecida com sucesso!");
               
                /*cria tabela 
                try (Statement st = conn.createStatement()) {
                    String createTableSql = "CREATE TABLE IF NOT EXISTS ALUNO (ID INT AUTO_INCREMENT PRIMARY KEY, NOME VARCHAR(255) NOT NULL)";
                    st.execute(createTableSql);

                    //insere um registro na tabela criada
                    String insertSql = "INSERT INTO ALUNO (NOME) VALUES ('LAÍZ')";
                    st.executeUpdate(insertSql);
                    System.out.println("Registro inserido com sucesso");

                    //seleciona o registro inserido para exibir 
                    try (ResultSet rs = st.executeQuery("SELECT NOME FROM ALUNO WHERE NOME = 'LAÍZ'")) {
                        if (rs.next()) {
                            System.out.println("Registro Encontrado: " + rs.getString("NOME"));
                        } else {
                            System.out.println("registro não encontrado ");
                        }
                    }
                }*/
               
                } 
                
            } 
        } finally {
            
        }
    } 
} 
