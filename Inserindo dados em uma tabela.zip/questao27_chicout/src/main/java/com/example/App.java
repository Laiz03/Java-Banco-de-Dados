package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 Crie um programa Java que insira dados em uma tabela chamada "clientes" no banco de dados MariaDB. 
 Solicite ao usuário que insira informações sobre um novo cliente, como nome, idade e endereço, e insira esses dados na tabela.
 */

 /**
Garanta que, em todos os programas anteriores, você encerre a conexão com o banco de dados MariaDB adequadamente após a 
conclusão das operações. Use a estrutura try-with-resources ou um bloco finally para garantir o fechamento da conexão.
 */

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
         Scanner entrada = new Scanner(System.in);

            //entrada das informações do usuário
            System.out.println("Digite o nome do cliente: ");
            String nome = entrada.nextLine();

            System.out.println("Digite a idade do cliente: ");
            int idade = entrada.nextInt();
            entrada.nextLine();

            // conexão e inserção de dados
         try (Connection conm = DriverManager.getConnection("jdbc:mariadb://localhost:3306/listachicoutbdb", "root", "root")) {
            String insertSql = "INSERT INTO cliente(nome, idade) VALUES(?, ?)";
            try (PreparedStatement pstmt = conm.prepareStatement(insertSql)) {
                pstmt.setString(1, nome);
                pstmt.setInt(2, idade);
                pstmt.executeUpdate();
            }

            String selectSql = "SELECT * FROM cliente";
            try (PreparedStatement pstmt = conm.prepareStatement(selectSql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    System.out.print(rs.getString("nome") + " ");
                    System.out.print(rs.getInt("idade") + " ");
                    System.out.println();
                }
            }

            String deleteSql = "DELETE FROM cliente WHERE id IN (5, 6, 7, 8, 9, 10, 11);";
            try(PreparedStatement pstmt = conm.prepareStatement(deleteSql)) {
                int affectedRows = pstmt.executeUpdate();
                System.out.println("Número de registros deletados: " + affectedRows);
            } 

        } finally {
            entrada.close();
        }
    }
}