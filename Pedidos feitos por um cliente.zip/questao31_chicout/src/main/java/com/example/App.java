package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


/*Escreva um programa Java que realize uma consulta SQL na tabela "pedidos" para recuperar todos os pedidos feitos por um cliente. 
Solicite ao usuário que insira o ID do cliente como parâmetro e exiba os resultados no console.
 */

  /**
Garanta que, em todos os programas anteriores, você encerre a conexão com o banco de dados MariaDB adequadamente após a 
conclusão das operações. Use a estrutura try-with-resources ou um bloco finally para garantir o fechamento da conexão.
 */

 
public class App 
{
    public static void main( String[] args ) throws SQLException
    {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Insira o ID do cliente: ");
        int id = entrada.nextInt();

        String selectSql = "SELECT * FROM pedido WHERE id_cliente = ?";

        try (Connection conect = DriverManager.getConnection("jdbc:mariadb://localhost:3306/listachicoutbdb", "root", "root");
            PreparedStatement ps = conect.prepareStatement(selectSql)) {
                ps.setInt(1, id);

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        System.out.println(rs.getInt(1) + " ");
                        System.out.println(rs.getString(2) + " ");
                        System.out.println(rs.getInt(3) + " ");
                        System.out.println(rs.getString(4) + " ");
                        System.out.println();
                    }
                }
        } finally {
            entrada.close();
        }
    } 
}